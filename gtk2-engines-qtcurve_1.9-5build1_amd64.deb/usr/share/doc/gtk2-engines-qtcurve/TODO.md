1. right to left

    1. kde style scrollbars. when pressing > buttons, both depress.
    2. qt file selector (other styles (Cleanlooks) have some issues too...)
    3. shift contents to left when pressed?

        1. Cant just set PM_ stuff, as also move arrows, etc.

2. Palette - doesnt seem to like changes!

3. 'fix' for kdialog/kdefilepicker skipping taskbar, etc.

4. Plasma/NVIDIA

    Borders of selected tab are 1 pixel to long.

5. Firefox

    Combobox is not drawn correctly, and doesnt hightlight on focus,
    but neither do other styles - think this is a firefox issue.

6. GTK/KDE have different disabled text behaviour when contrast
   setting changed!

7. Gtk3?????

8. Qt MdiSubWindow shadow and blur.

9. Redo configure system and interface.

10. Test prepolish. See if we can remove the recreating window trick all together.

11. QPainter composition mode.

12. Change cursor shape while draging the window in empty area.

13. Separate drawing routines (for both gtk and qt) and add tests for them.
